
  # Account Settings Wireframe

  This is a code bundle for Account Settings Wireframe. The original project is available at https://www.figma.com/design/J5puXrvrR9m79il8dCg5av/Account-Settings-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  