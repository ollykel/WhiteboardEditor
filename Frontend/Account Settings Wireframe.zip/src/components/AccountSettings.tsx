// This is a re-export from the pages directory
// The actual component has been moved to /pages/AccountSettings.tsx
export { AccountSettings } from "../pages/AccountSettings";