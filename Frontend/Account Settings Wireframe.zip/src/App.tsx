import { AccountSettings } from "./pages/AccountSettings";

export default function App() {
  const handleSaveProfileChanges = () => {
    console.log("Profile changes saved");
    // TODO: Implement profile update logic
  };

  const handleUpdateSecuritySettings = () => {
    console.log("Security settings updated");
    // TODO: Implement security settings update logic with password confirmation
  };

  const handleDeleteAccount = () => {
    console.log("Account deletion confirmed");
    // TODO: Implement actual account deletion API call
    alert("Account deletion confirmed. This would normally call the API to delete the account.");
  };

  return (
    <div className="min-h-screen bg-background">
      <AccountSettings 
        onSaveProfileChanges={handleSaveProfileChanges}
        onUpdateSecuritySettings={handleUpdateSecuritySettings}
        onDeleteAccount={handleDeleteAccount}
      />
    </div>
  );
}